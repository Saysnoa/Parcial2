-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: almacen_limpieza
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id_producto` int NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `precio_unitario_ars` decimal(10,2) DEFAULT NULL,
  `es_oferta` tinyint DEFAULT '0',
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Detergente Líquido',1200.00,0),(2,'Lavandina Concentrada',950.00,0),(3,'Limpiavidrios',800.00,1),(4,'Desinfectante Floral',1100.00,0),(5,'Suavizante de Ropa',1300.00,1),(6,'Limpiador Multiuso',900.00,0),(7,'Desengrasante Cocina',1250.00,1),(8,'Jabón en Polvo',1450.00,0),(9,'Limpiador Pisos',1000.00,0),(10,'Cera para Muebles',1600.00,0),(11,'Ambientador Spray',750.00,0),(12,'Toallas Desinfectantes',950.00,0),(13,'Limpiador de Baños',980.00,0),(14,'Lustramuebles',1550.00,0),(15,'Detergente para Vajilla',1150.00,0),(16,'Jabón Líquido Manos',880.00,0),(17,'Aromatizante Ambiental',760.00,0),(18,'Limpiador de Alfombras',1200.00,0),(19,'Quitamanchas',1400.00,0),(20,'Cloro Gel',890.00,0),(21,'Desodorante Piso',950.00,0),(22,'Desinfectante Pino',1020.00,0),(23,'Pulidor Metales',1650.00,0),(24,'Cera para Autos',1700.00,0),(25,'Limpiador Antigrasa',980.00,0),(26,'Lavavajilla Industrial',2000.00,0),(27,'Shampoo Alfombra',1500.00,0),(28,'Limpia Inodoro',870.00,0),(29,'Suavizante Concentrado',1450.00,0),(30,'Limpia Hornos',2100.00,0);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-29 22:54:56
